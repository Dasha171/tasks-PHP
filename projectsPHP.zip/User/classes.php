<?php
//перенесено
abstract class UserAbstract{
        abstract public function showInfo();
       }

       interface ISuperUser{
        public function  getInfo();     
       }
    interface  IAuthorizeUser{
        public function auth($login, $password);
    }
class SU implements IAuthorizeUser{
    public function getInfo(){
        $countries = ["name" => "doshik", "login" => "Dasha", "password" => "123"];
        print_r($countries);
    }

    public function auth($login,$password){
        if($login=='Dasha'){
          return true;
        }else if($password=='123'){
            return true;
        }else{
            return false;
        }
    }
}
    $abs = new SU('dasha','far','123','sq');
    $abs->getInfo();
    $abs->auth('axa','axa');//false
    ?>