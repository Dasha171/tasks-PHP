<?php
       class User{
        public $name;
        public $login;
        public $password;
        public static $num = 0;

 public function __construct($name, $login, $password){
            $this->name = $name;
            $this->login = $login;
            $this->password = $password;
            echo ( ++self::$num);
        }

public function __destruct(){
              echo "$this->login удален";
}
        public function showInfo(){
           echo $this->name;
           echo $this->login;
           echo $this->password;
        }
}

       //унаследован ISuperUser
       //унаследован IAuthorizeUser
    class SuperUser extends User{
        public $role;
        public static $num = 0;
        public function __construct($name, $login, $password, $role){
        	parent::__construct($name, $login, $password);
            echo ( ++self::$num );
		    $this->role = $role;
        }
        public function showInfo(){
            parent::showInfo();
            echo $this->role.'<br>';
        }
       }
//Часть 2 перенесена
    require('classes.php');

       //вывод
       $user1 = new User('doshik'.'<br>','Dasha'.'<br>',123 .'<br>');
       $user2 = new User('doshik'.'<br>','Dasha'.'<br>',123 .'<br>');
       $user3 = new User('doshik'.'<br>','Dasha'.'<br>',123 .'<br>');
       $user1->showInfo();
       $user2->showInfo();
       $user3->showInfo();

       echo "SuperUser".'<br>';
        $super = new SuperUser('doshik'.'<br>','Dasha'.'<br>',123, 'dock');
        $super->showInfo();
        echo '<br>'.'Обычных пользователей: ' . User::$num;
        echo '<br>';
        echo '<br>'.'Супер пользователей: ' . SuperUser::$num;



//http://localhost/User/users.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
</head>
<body>
    
</body>
</html>