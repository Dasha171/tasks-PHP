<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       body{
        text-align: center;
        background-image: url(2.jpg);
        font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
      font-size: 30px;
       }
    </style>
</head>
<body>
<?php
require_once 'NewsDB.class.php';
$news = new NewsDB();
$id = (int) $_GET['id'];
if(!$id){
    echo $errMsg;
    exit;
}else{
   $arr = $news->showNews($id);
  
 foreach($arr as $array){
   
        echo $array['title']."<br>";
        echo $array['category']."<br>";
        echo $array['description']."<br>";
        echo $array['source']."<br><br>";
    }
 }?>
 </body>
</html>
