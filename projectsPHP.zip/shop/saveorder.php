<?php

require "inc/lib.inc.php";
require "inc/config.inc.php";
require "basket.php";

global $basket;

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];


$result = myBasket();

$myfile = fopen("admin/" . ORDERS_LOG, "w+");
foreach ($result as $item) {
    $id = $item['id'];
    $title = $item['title'];
    $author = $item['author'];
    $pubyear = $item['pubyear'];
    $price = $item['price'];
    $count = $basket[$id];
    $ordertime = time();

    $order = "$name|$email|$phone|$address|$id|$ordertime\n";

    fwrite($myfile, $order);
    echo $order;
}
saveOrder($ordertime);
fclose($myfile);
?> 
<!DOCTYPE html> 
<html> 
 
<head> 
 <meta charset="utf-8"> 
 <title>Сохранение данных заказа</title> 
</head> 
 
<body> 
 <p>Ваш заказ принят.</p> 
 <p><a href="catalog.php">Вернуться в каталог товаров</a></p> 
</body> 
 
</html>