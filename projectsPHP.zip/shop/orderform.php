<?php
require "inc/lib.inc.php";
$result = myBasket();

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Форма оформления заказа</title>
</head>
<body>
<h1>Оформление заказа</h1>
<?php
echo "<form action='saveorder.php' method='post'>"


?>
<p>Заказчик:</p>
<input type='text' name='name' size='50'>
<p>Email заказчика: </p>
<input type='text' name='email'
       size='50'>
<p>Телефон для связи:</p>
<input type='text' name='phone'
       size='50'>
<p>Адрес доставки: </p>
<input type='text' name='address'
       size='100'>

<input type='submit' value='Заказать'>
</form>
</body>
</html>