<?php

require "config.inc.php";
global $conn_pg;

function addItemToCatalog($title, $author, $pubyear, $price)
{
    $sql = 'INSERT INTO catalog (title, author, pubyear, price) VALUES ($1, $2, $3, $4)';
    global $conn_pg;

    $stmt = pg_prepare($conn_pg, "add_item", $sql);
    if (!$stmt)
        return false;

    $result = pg_execute($conn_pg, "add_item", array($title, $author, $pubyear, $price));
    if (!$result)
        return false;

    return true;

}

function selectAllItems($conn_pg)
{
    $sql = 'SELECT id, title, author, pubyear, price FROM catalog';
    if (!$result = pg_query($conn_pg, $sql))
        return false;
    $items = pg_fetch_all($result, PGSQL_ASSOC);
    pg_free_result($result);
    return $items;
}

function saveBasket()
{
    global $basket;
    $basket = base64_encode(serialize($basket));
    setcookie('basket', $basket, 0x7FFFFFFF);

}


function basketInit()
{
    global $basket, $count;
    if (!isset($_COOKIE['basket'])) {
        $basket = ['orderid' => uniqid()];
        saveBasket();
    } else {
        $basket = unserialize(base64_decode($_COOKIE['basket']));
        $count = count($basket) - 1;  //у вас тут подсчет всех уникальных элементов в корзине, не учитывая count внутри каждого заказа
    }
}

function add2Basket($id)
{
    global $basket;
    $basket[$id] += 1;
    saveBasket();
}

function myBasket()
{
    global $conn_pg, $basket;
    $goods = array_keys($basket);
    array_shift($goods);
    if (!$goods)
        return false;
    $ids = implode(",", $goods);
    $sql = "SELECT id, author, title, pubyear, price FROM catalog WHERE id IN ($ids)";
    if (!$result = pg_query($conn_pg, $sql))
        return false;
    $items = result2Array($result);
    pg_free_result($result);
    return $items;
}

function result2Array($data)
{
    global $basket;
    $arr = [];
    while ($row = pg_fetch_assoc($data)) {
        $row['quantity'] = $basket[$row['id']];
        $arr[] = $row;
    }
    return $arr;
}

function deleteItemFromBasket($id)
{
    global $basket;
    unset($basket[$id]);
    saveBasket();
}

function saveOrder($datetime)
{
    global $conn_pg, $basket;
    $goods = myBasket();
    echo print_r($goods);
    $sql = 'INSERT INTO orders (
title,
author,
pubyear,
price,
quantity,
orderid,
datetime)
VALUES ($1, $2, $3, $4, $5, $6, $7)';

    foreach ($goods as $item) {

        pg_query_params($conn_pg, $sql, array(
            $item['title'], $item['author'],
            $item['pubyear'], $item['price'],
            $item['quantity'],
            $item['id'],
            $datetime
        ));
    }
    unset($_COOKIE);
    return true;
}

function getOrders()
{

    global $conn_pg;
    if (!is_file("/Users/vercello/PhpstormProjects/php_labs/siteb-eshop/admin/orders.log"))
        return false;
    $orders = file("/Users/vercello/PhpstormProjects/php_labs/siteb-eshop/admin/orders.log");
    $allorders = [];

    foreach ($orders as $order) {
        list($name, $email, $phone, $address, $orderid, $date) = explode("|",
            $order);
        $orderinfo = [];
        $orderinfo["name"] = $name;
        $orderinfo["email"] = $email;
        $orderinfo["phone"] = $phone;
        $orderinfo["address"] = $address;
        $orderinfo["orderid"] = $orderid;
        $orderinfo["date"] = $date;
        $sql = "SELECT title, author, pubyear, price, quantity
    FROM orders
    WHERE orderid = $1 AND datetime = $2";
        if (!$res = pg_query_params($conn_pg, $sql, array($orderid, $date)))
            return false;
        $items = pg_fetch_all($res);
        pg_free_result($res);
        $orderinfo["goods"] = $items;
        $allorders[] = $orderinfo;

    }
    return $allorders;

}


