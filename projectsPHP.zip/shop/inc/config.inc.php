<?php

//require_once __DIR__ . 'siteb-eshop/inc/config.inc.php';
//
//$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
//$dotenv->load();
//
$DB_HOST = "45.89.67.77";
$DB_LOGIN = "postgres";
$DB_PASSWORD = "vercello";
$DB_NAME = "shop";
$ORDERS_LOG = "orders.log";
$basket = [];
$count = 0;
$conn_pg = pg_connect("host=$DB_HOST dbname=$DB_NAME user=$DB_LOGIN password=$DB_PASSWORD");

basketInit();
