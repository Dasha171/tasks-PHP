<?
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: /phpp/shop/admin/secure/login.php?ref=' . $_SERVER['REQUEST_URI']);
    exit;
}
