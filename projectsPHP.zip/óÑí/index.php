<?php
session_start();

if (!isset($_SESSION['username'])) {
//   header('Location: login.php');
//   exit();
}

// Ваш код для защищенной страницы
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Films</title>
</head>
<body>
<?php
$host = 'localhost';
$login = 'root';
$password = '';
$database = 'sotrudniki';

$connection = mysqli_connect($host, $login, $password, $database);

// Проверка соединения
if (!$connection) {
    die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
}

?>
<title>Сотрудники</title>
    <style>
        body{
            background-color:black;
            color: aliceblue;
            /* text-align: center; */
            font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
            font-size: 20px;
            margin-top: 100px;
            margin-left: 300px;
        }
        #s{
           text-align: center;
           padding-bottom: 80px;
           margin-right: 300px;
           font-family:Georgia, 'Times New Roman', Times, serif;
        }
        tr, td{
            border-radius: 2px;
        }
    </style>
     <h1 id="s">Фильмы</h1>
<?php
 $query = "SELECT * FROM wp_employees";
 $result = mysqli_query($connection, $query);
while ($row = mysqli_fetch_assoc($result)) {
      
    $full_name = $row['full_name'];
    $date_of_birth = $row['date_of_birth'];
    $address = $row['address'];
    $position = $row['position'];

    // echo "Название фильма: $full_name<br>";
    // echo "Дата выхода: $date_of_birth<br>";
    // echo "Возраст: $address<br>";
    // echo "Жанр: $position<br><br>";
}
?>
<style>
    .hh{
        display: grid;
        grid-template-columns: 600px 400px;
        grid-template-rows: 600px;
        
    }
    #kk{
       height: 400px;
       width: 300px;

    }
    .h5, .h6{
        margin-top: 70px;
    }
</style>
<div class="hh">
    <div class="h1">
        <img src="hhhh.jpg" alt="" id="kk">
        <br>
        <br>
        <?php 
        
        echo "Название фильма: $full_name<br>";
    echo "Дата выхода: $date_of_birth<br>";
    echo "Возраст: $address<br>";
    echo "Жанр: $position<br><br>";?>
    </div>
    <div class="h2">
    <img src="jjj.jpg" alt="" id="kk">
        <br>
        <br>
        <?php 
        echo "Название фильма: В тихом омуте<br>";
    echo "Дата выхода: 2020-08-12<br>";
    echo "Возраст: 18+<br>";
    echo "Жанр: Ужасы <br><br>";?>
    </div>
    <div class="h3">
        <img src="kkkk.jpg" alt="" id="kk">
        <br>
        <br>
        <?php 
        echo "Название фильма: И гаснет свет<br>";
    echo "Дата выхода: 2019-09-15<br>";
    echo "Возраст: 18+<br>";
    echo "Жанр: Ужасы<br><br>";?>
    </div>
    <div class="h4">
    <img src="sss.jpg" alt="" id="kk">
        <br>
        <br>
        <?php 
        echo "Название фильма: Из моего окна<br>";
    echo "Дата выхода: 2019-09-15<br>";
    echo "Возраст: 18+<br>";
    echo "Жанр: Романтика/Комедия<br><br>";?>
    </div>

    <div class="h5">
        <img src="dd.jpg" alt="" id="kk">
        <br>
        <br>
        <?php 
        echo "Название фильма: Мадагаскар<br>";
    echo "Дата выхода: 2019-09-15<br>";
    echo "Возраст: 6+<br>";
    echo "Жанр: Мультфильм<br><br>";?>
    </div>
    <div class="h6">
    <img src="sss.webp" alt="" id="kk">
        <br>
        <br>
        <?php 
        echo "Название фильма: Воспоминания о будущем<br>";
    echo "Дата выхода: 2019-09-15<br>";
    echo "Возраст: 16+<br>";
    echo "Жанр: Романтика<br><br>";?>
    </div>
</div>

</body>
</html>
