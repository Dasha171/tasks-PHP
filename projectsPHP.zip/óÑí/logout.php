<?php
// Получение отправленных данных из формы
$username = $_POST['username'];
$password = $_POST['password'];

$host = 'localhost';
$login = 'root';
$password = '';
$database = 'database_name';

$connection = mysqli_connect($host, $login, $password, $database);

// Проверка соединения
if (!$connection) {
    die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
}
if($username == "dasha" && $password = "1234" ){
     header('Location: index.php');
   exit();
     }else{
          echo("error");
     }
?>
