
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Веб-приложение</title>
    <style>
        body{
            background-color:grey;
            text-align: center;
            color: aliceblue;
            font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif
        }
        #s{
           text-align: center;
        }
        a{
            text-decoration: none;
            padding: 20px;
            border: 1px solid rgb(255, 255, 255);
            border-radius: 30px;
            text-align: center;
            color: aliceblue;

        }
        h1{
            padding: 50px;
            text-align: center;
            
        }
        header{
            height: 300px;
        }
    </style>
</head>
<body>
    <header>
    <h1>Выбор БД</h1>

    </header>
    <br>
    <br>
    <a href="sot.php" class="a">Сотрудники</a>
    <a href="buh.php" class="a">Бухгалтерия</a>
</body>
</html>