<style>
  input{
    text-align: center;
    height: 40px;
    width: 200px;
    
  }
  form{
    align-items: center;
  }
  .inp{
    text-align: center;
    padding: 150px;
  }
  #gg{
    height: 30px;
    width: 100px;
  }
</style>
<div class="inp">
<form action="logout.php" method="POST">
  <input type="text" name="username" placeholder="Имя пользователя"><br>
  <br>
  <input type="password" name="password" placeholder="Пароль"><br>
  <br>
  <br>
  <input type="submit" value="Войти" id="gg">
</form>
</div>
