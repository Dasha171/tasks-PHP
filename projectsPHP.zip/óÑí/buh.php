<?php
$host = 'localhost';
$login = 'root';
$password = '';
$database = 'sotrudniki';

$connection = mysqli_connect($host, $login, $password, $database);

// Проверка соединения
if (!$connection) {
    die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
}

?>
<title>Сотрудники</title>
    <style>
        body{
            background-color:grey;
            color: aliceblue;
            /* text-align: center; */
            font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
            font-size: 20px;
            margin-top: 100px;
            margin-left: 100px;
        }
        #s{
           text-align: center;
           padding-bottom: 80px;
        }
        tr, td{
            border-radius: 2px;
        }
        #img{
            height: 170px;
        }
    </style>
     <h1 id="s">Бухгалтерия</h1>
     <div class="box">
      <img src="3.jpg" alt="" id="img">
<?php
 $query = "SELECT * FROM bux";
 $result = mysqli_query($connection, $query);
while ($row = mysqli_fetch_assoc($result)) {
      
    $id = $row['id'];
    $full_name = $row['full_name'];
    $position = $row['position'];
    $salary = $row['salary'];
    $bonuses = $row['bonuses'];
    $tax_percentage = $row['tax_percentage'];
    $total_salary = $row['total_salary'];

    echo "ФИО: $full_name<br>";
    echo "Должность: $position<br><br>";
    echo "Зарплата: $salary<br>";
    echo "Премия: $bonuses<br>";
    echo "Зарплата: $salary<br>";
    echo "Процент: $tax_percentage<br>";
    echo "Итог: $total_salary<br>";
}
?>
   </div>