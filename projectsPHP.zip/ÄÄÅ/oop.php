<?
   //ферма 1 - 2.0
abstract class Animal {
public function say() {
      echo "звук животного";
  }
  
  abstract public function walk();
}
abstract class HoofAnimals extends Animal {
public function walk() {
      echo "топ-топ";
  }
}
abstract class Bird extends Animal {
public function walk() {
      $this->tryToFly();
  }
  
public function tryToFly() {
      echo "вжих-топ-топ";
  }
}
class Cow extends HoofAnimals {
public function say() {
      echo "му <br>"; 
  }

  public function walk() {
      echo "топ-топ <br>"; 
  }
}
class Pig extends HoofAnimals {
public function say() {
      echo "хрю <br>"; 
  }

  public function walk() {
      echo "топ-топ <br>"; 
  }
} 
class Chicken extends Bird {
public function say() {
      echo "ку-ка-ре-ку <br>"; 
  }

public function walk() {
      echo "топ-топ <br>";
  }
 public function tryToFly() {
      echo "вжих-топ-топ";
  }
}
class Goose extends Bird {
public function say()
  {
      echo "га-га <br>";
  }
  public function walk() {
      echo "топ-топ <br>";
  }

  public function tryToFly() {
      echo "вжих-топ-топ";
  }
}
class Turkey extends Bird {
public function say()
  {
      echo "га <br>";
  }
  public function walk() {
      echo "топ-топ <br>";
  }
  public function tryToFly() {
      echo "вжих-топ-топ";
  }
}
class Horse extends HoofAnimals {
public function say()
  {
      echo "его-го <br>";
  }
  public function walk() {
      echo "топ-топ <br>";
  }
}
class Farm {
public $animals = array();
  public function addAnimal(Animal $animal) {
      $this->animals[] = $animal;
      $animal->walk();
  } 
public function say() {
      foreach ($this->animals as $animal) {
          $animal->say();
      }
  }
  
  public function rollCall() {
      shuffle($this->animals);
      foreach ($this->animals as $animal) {
          $animal->say();
      }
      
  }
}
class BirdFarm extends Farm {
public $maxAnimalsCount = 10;
  
public function addAnimal(Animal $animal) {
      if (count($this->animals) >= $this->maxAnimalsCount) {
          echo "Птицеферма заполнена ";
          return;
      }  
    parent::addAnimal($animal);
  }  
public function showAnimalsCount() {
      echo "Птиц на ферме : " . count($this->animals);
  }
}

class Farmer {
public function runFarm(Farm $farm) {
      $cow = new Cow();
      $farm->addAnimal($cow);
      $pi1 = new Pig();
      $farm->addAnimal($pi1);  
      $pi2 = new Pig();
      $farm->addAnimal($pi2);  
      $chic = new Chicken();
      $farm->addAnimal($chic);
      $turk1 = new Turkey();
      $farm->addAnimal($turk1);
      $turk2 = new Turkey();
      $farm->addAnimal($turk2);
      $turk3 = new Turkey();
      $farm->addAnimal($turk3);
      $hor1 = new Horse();
      $farm->addAnimal($hor1);
      $hor2 = new Horse();
      $farm->addAnimal($hor2);      
      $gos = new Goose();
      $farm->addAnimal($gos);      
      $farm->say();
      
  }
  
  public function runBirdFarm(BirdFarm $birdFarm) {
      $chik = new Chicken();
      $birdFarm->addAnimal($chik);
      $birdFarm->showAnimalsCount();      
      $gos = new Goose();
      $birdFarm->addAnimal($gos);
      $birdFarm->showAnimalsCount();      
      $turk = new Turkey();
      $birdFarm->addAnimal($turk);
      $birdFarm->showAnimalsCount();
  }
}
$farmers = new Farmer();
$farm = new Farm();
$farmers->runFarm($farm);
$birdFarm = new BirdFarm();
$farmers->runBirdFarm($birdFarm);

    //метод перекличка рандом
    // public function rollCall(){
    //  for($i = 1; $i <= 3; $i++){
    //       $rand = rand(1,3);
    //       switch($rand){
    //         case 1;
    //         $cow = new Cow();
    //         array_push($this -> animals, $cow -> say());
    //         break;
    //         case 2;
    //         $pig = new Pig();
    //         array_push($this -> animals, $pig -> say());
    //         break;
    //         case 3;
    //         $chik = new Chiken();
    //         array_push($this -> animals, $chik -> say());
    //         break;
    //       }
    //     }
    // }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>